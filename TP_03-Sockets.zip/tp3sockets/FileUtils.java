package tp3sockets;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.io.File;

/**
 * Clase utilitaria para la selección de archivos
 */
public class FileUtils {
    
    /**
     * Permite al usuario seleccionar un archivo mediante un cuadro de diálogo
     * @return File seleccionado o null si se cancela la operación
     */
    public static File selectFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Seleccionar archivo para enviar");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        
        int result = fileChooser.showOpenDialog(null);
        
        if (result == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile();
        }
        
        return null;
    }
    
    /**
     * Pregunta al usuario si desea enviar otro archivo
     * @return true si desea continuar, false si desea finalizar
     */
    public static boolean askForContinue() {
        int option = JOptionPane.showConfirmDialog(
            null, 
            "¿Desea enviar otro archivo?", 
            "Continuar transmisión", 
            JOptionPane.YES_NO_OPTION
        );
        
        return option == JOptionPane.YES_OPTION;
    }
    
    /**
     * Obtiene el nombre del archivo sin la ruta completa
     * @param filePath ruta completa del archivo
     * @return nombre del archivo
     */
    public static String getFileName(String filePath) {
        return new File(filePath).getName();
    }
    
    /**
     * Formatea el tamaño del archivo en una unidad legible
     * @param bytes tamaño en bytes
     * @return tamaño formateado (ej: 1.5 KB, 2.3 MB)
     */
    public static String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        String pre = "KMGTPE".charAt(exp - 1) + "";
        return String.format("%.1f %sB", bytes / Math.pow(1024, exp), pre);
    }
}