package tp3sockets;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Clase para logging del servidor con colores
 */
public class ServidorLogger {
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");
    
    /**
     * Log de información general
     */
    public static void logInfo(String message) {
        String timestamp = LocalDateTime.now().format(TIME_FORMATTER);
        ConsoleColors.printInfo("[" + timestamp + "] INFO: " + message);
    }
    
    /**
     * Log de éxito
     */
    public static void logSuccess(String message) {
        String timestamp = LocalDateTime.now().format(TIME_FORMATTER);
        ConsoleColors.printSuccess("[" + timestamp + "] SUCCESS: " + message);
    }
    
    /**
     * Log de error
     */
    public static void logError(String message) {
        String timestamp = LocalDateTime.now().format(TIME_FORMATTER);
        ConsoleColors.printError("[" + timestamp + "] ERROR: " + message);
    }
    
    /**
     * Log de advertencia
     */
    public static void logWarning(String message) {
        String timestamp = LocalDateTime.now().format(TIME_FORMATTER);
        ConsoleColors.printWarning("[" + timestamp + "] WARNING: " + message);
    }
}